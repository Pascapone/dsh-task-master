# Verwaltete Entwicklungsprozesse und DSH-Test-Gateways

Das DSH-Plugin stellt `devGateways` für Git und Task Master und `dev_gateway` für Agents bereit. **Entwicklungsserver, Backends, Listener, Watcher und andere dauerhafte lokale Projektprozesse werden darüber gestartet**, statt sie detached in der Shell zurückzulassen. Daneben sind isolierte DSH-Testinstanzen möglich. Alle erhalten einen verwalteten Prozess, Lease, Logs und einen reservierten Loopback-Port (standardmäßig 3200–3299), der ohne Netzwerkmodus ungenutzt bleiben kann. Production wird weder beendet noch als Entwicklungs-/Build-Worktree verwendet.

## Zwei Serverarten

- **`kind: "project"`**: Ein gewöhnlicher Entwicklungsprozess (Node, Python oder andere Programme). Keine DSH-Identity, keine Bundle-/Paketinstallation. Start über ein vorhandenes npm-/pnpm-Skript oder `manager: "command"` mit einem argv-Array. `readyMode: "http"` (Standard) prüft eine lokale HTTP-Adresse, `"tcp"` einen TCP-Listener am zugewiesenen Port, `"process"` nur, ob der Prozess nach 1,2 Sekunden noch läuft (z. B. Watcher ohne Port). Das Programm läuft im gewählten Projektverzeichnis und muss im Vordergrund bleiben.
- **`kind: "dsh"`**: Ein eigener DSH-Home und ein eigenes Web-Profil. Installiert das Identity-Plugin und explizit ausgewählte lokale DSH-Bundles. Prüft Instanzidentität und Browser-Login. `manager: "dsh"` führt die gebaute Controller-Runtime aus; das testet **nicht automatisch Änderungen am DSH-Quellcode**. Ein eigener npm-/pnpm-Launcher kann stattdessen eine separate Development-Runtime starten.

Das Workspace-Verzeichnis benötigt kein `dsh.bundle`. Nur tatsächlich zu installierende DSH-Bundles brauchen dieses Manifestfeld. Ein Projekt ohne `package.json` kann einen direkten Befehl verwenden.

## Agent-Tool: normaler Ablauf

1. `configuration` mit absolutem `workspace`: gespeicherte Optionen, vorhandene Skripte und Befehlsvorschau ansehen.
2. `configure` mit `workspace`, `kind: "project"`, `manager`, passendem `script` oder `command` und ggf. `readyMode`: einmalig speichern. Nur für isolierte DSH-Instanzen `kind: "dsh"` wählen. Die Konfiguration liegt außerhalb des Worktrees und wird zwischen Git-Oberfläche und Agent geteilt.
3. `start` mit `workspace`, `label`, eindeutiger `requestId`, optional `bundles`, `leaseMinutes`, `watch`, `retainData`: gibt sofort ID und Status `starting` zurück. Derselbe Request ist idempotent; bei Wiederholung dieselbe Request-ID verwenden.
4. `status` mit `id`: tatsächlichen Zustand prüfen. `ready` bedeutet je nach Modus HTTP-Antwort, erreichbaren TCP-Port oder nach der Startfrist noch laufenden Prozess; bei DSH zusätzlich geprüfte Identität und Login-Link. `start` selbst bestätigt noch keine erfolgreiche Bereitschaft.
5. `logs` mit `id`, optional `from`: stdout/stderr von Start, Build, Watchern und Server. `next` als nächsten Cursor verwenden; `hasMore` zeigt weitere Seiten, `lossy` verlorene ältere Ausgabe. Nach regulärem Stop nur bei `retainData: true`; Fehlerlogs bleiben erhalten.
6. `access` mit `id` nur für HTTP/DSH: liefert den sicheren Öffnungslink `url`, die tokenfreie Adresse `serverUrl` und ausdrücklich die möglicherweise **sensitive** `loginUrl`. Für TCP-/Prozess-Modus gibt es keinen Browser-Link. Normales Inventar enthält keine Browser-Tokens. DSH-Token werden in Logs maskiert, auch bei über mehrere Chunks verteilten Zeilen.
7. `stop` oder `extend` mit `id`, bei Verlängerung `minutes` (1–480). `list` zeigt eigene Instanzen.

Agent-Konfiguration und Start erfordern `danger-full-access`. Agents dürfen nur eigene Instanzen ansehen/steuern; Operatoren in Git und Task Master auch agentgestartete Server. Agent-Instanzen hängen als verwaltete Jobs an der Session; Git-Operator-Instanzen haben zusätzlich eine geprüfte Herkunfts-Session. Standard-Lease: 120 Minuten. `configuration` beschreibt die Temp-Daten-Regel; `start`/`status` zeigen den konkreten `dataDir` und die Archiv-Policy.

### Beispiele

Vite mit explizitem Host/Port (kein stilles Ausweichen auf einen anderen Port):

```json
{"action":"configure","workspace":"C:\\projects\\website","kind":"project","manager":"npm","script":"dev","args":["--host","{host}","--port","{port}","--strictPort"]}
{"action":"start","workspace":"C:\\projects\\website","label":"Website Dev-Server","requestId":"website-dev-1"}
```

Python, ohne Paketmanifest:

```json
{"action":"configure","workspace":"C:\\projects\\website","kind":"project","manager":"command","command":["python","-m","http.server","{port}","--bind","{host}"]}
```

TCP-Backend/Listener (reagiert nicht auf HTTP):

```json
{"action":"configure","workspace":"C:\\projects\\backend","kind":"project","manager":"command","command":["node","server.js","--port","{port}"],"readyMode":"tcp"}
{"action":"start","workspace":"C:\\projects\\backend","label":"Backend Listener","requestId":"backend-1"}
```

Watcher oder sonstiger dauerhafter Prozess ohne Port:

```json
{"action":"configure","workspace":"C:\\projects\\website","kind":"project","manager":"npm","script":"watch","readyMode":"process"}
{"action":"start","workspace":"C:\\projects\\website","label":"Website Watcher","requestId":"website-watch-1"}
```

Isolierter DSH-Standard:

```json
{"action":"configure","workspace":"C:\\projects\\my-plugin","kind":"dsh","manager":"dsh"}
{"action":"start","workspace":"C:\\projects\\my-plugin","bundles":["C:\\projects\\my-plugin"],"label":"Plugin-Test","requestId":"plugin-test-1"}
```

Befehle sind argv-Arrays, keine Shell-Strings; jedes Argument bleibt separat. `{host}`/`{port}` werden ersetzt. Skripte erhalten zusätzlich `HOST`, `PORT`, `DEV_GATEWAY_HOST`, `DEV_GATEWAY_PORT` sowie kompatible `DSH_DEV_GATEWAY_*`-Variablen. `http` prüft `readyPath` (Standard `/`, nur lokaler Pfad ohne Query/Fragment): 2xx/3xx/401/403 bedeutet bereit, 404/5xx nicht. `tcp` versucht eine Verbindung zum zugewiesenen Loopback-Port. `process` wartet nur 1,2 Sekunden auf das Überleben des gestarteten Prozesses; der reservierte Port kann ungenutzt bleiben. Netzwerk-Readiness ist kein DSH-Identitätsnachweis und ein fremder Listener könnte antworten. Das gestartete Programm muss im Vordergrund bleiben; Netzprozesse müssen den zugewiesenen Port exklusiv verwenden und an Loopback binden. Abhängigkeiten eines Projekts vorher selbst installieren.

## Temporäre App-Daten und Archivieren

Jeder **neu gestartete** Gateway-Prozess erhält `DEV_GATEWAY_DATA_DIR` mit einem eigenen, vom Manager angelegten `instances/<id>/data/`. Die App oder ihr Startskript muss wegwerfbare Datenbanken, Caches und Testprofile **selbst** dorthin legen; das Gateway kennt das Datenformat der App nicht. Beispiel für ein projektspezifisches Node-Startskript:

```js
import { join } from 'node:path';
const dbFile = join(process.env.DEV_GATEWAY_DATA_DIR, 'app.sqlite');
// Die App hier mit dbFile als Datenbankpfad starten und im Vordergrund lassen.
```

`DSH_HOME` isoliert schon das DSH-Testprofil unter `home/`; weder Projekt-CWD noch `HOME`/`USERPROFILE` werden umgebogen. Dateien, die eine fremde App dort ablegt, werden **nicht** automatisch gelöscht. Ein normaler Stop behält `data/` und Profil für Diagnose; das vorhandene Operator-`prune` löscht sie bei bestätigtem Prozessende. `retainData: true` verhindert auch dieses Prune.

Für **neue** Gateways mit Sessionbindung und ohne `retainData` gilt zusätzlich: Nach Archivierung der Steuer-Session wird der Prozess gestoppt und erst nach bestätigtem Ende die *Gateway-eigene* Instanz mitsamt `data/`, DSH-Testprofil, Test-Sessions, Logs und Inventareintrag entfernt. Auch ein ruhendes, schon gestopptes Gateway wird so bereinigt. Archivierte Steuer-Session, Verlauf, Projektordner und Git-Worktree bleiben bestehen; Entarchivieren stellt gelöschte Testprofile **nicht** wieder her. Ohne zugeordnete Session und für bereits vor dieser Funktion angelegte Instanzen gibt es **keine rückwirkende** Archiv-Löschung; `retainData: true` bewahrt die Instanzdaten, laufende Prozesse werden beim Stoppen-und-Archivieren trotzdem beendet.

Cleanup läuft *nach* dem dauerhaften Archiv-Commit und kann später enden oder bei Windows-Dateisperren bzw. `unknown` blockiert bleiben. Task Master zeigt ausstehende/blockierte Einträge; bestätigtes `unknown` wird nie automatisch freigegeben. Nach Controller-Neustart werden nur sicher fortsetzbare Fälle nachgeholt. Ein schnelles Entarchivieren plus Absturz genau vor Speicherung des Cleanup-Wunsches ist ohne Core-Commit-Hook nicht atomar abzusichern. Externe oder frei gewählte Löschpfade sind bewusst nicht unterstützt.

## Git und Task Master

Git zeigt Session-Zustand und Dev-Server-Zustand getrennt. Konfigurieren/Starten erfordern kein DSH-Bundle; Konfigurationsfehler bleiben sichtbar. Operatoren dürfen auch Agent-Server stoppen. Aktive Referenzen verhindern weiter das Löschen eines verwendeten Worktrees.

Task Master zeigt Serverart, Owner, Startbefehl, temporären Datenpfad und dessen Archiv-Policy, Logs, Lease und Stop. Der authentifizierte Öffnungs-Endpunkt leitet lokal zum Browser-Login weiter. **Remote-Browser über FRP oder Mobilgeräte können Loopback-Server nicht direkt öffnen.** Dafür wäre ein eigener abgesicherter Proxy nötig; das Plugin öffnet keinen öffentlichen Port.

## Isolation und Betrieb

Der Controller darf im Production-Host laufen. Die gebaute Host-Runtime wird nur ausgeführt, nie als Entwicklungs-/Build-Ziel benutzt. Jeder Server erhält einen separaten Datenordner; DSH-Instanzen zusätzlich getrennte Profile/Sessions. Prozesscontainment ist keine Sandbox für Projektcode: Skripte laufen mit den Rechten des Host-Benutzers.

Ohne `stateDir` liegt der Zustand neben `DSH_HOME`: für `~/.dsh` unter `~/dsh-production-dev-gateways`, ansonsten `<Home-Name>-dev-gateways`. Pfade/Junctions in Production-Homes und Host-Worktrees werden abgelehnt. Eine vorhandene `manager.lock` nie bei laufendem Controller löschen.

Optionale Host-Konfiguration: `runtimeDir` (gebauter DSH-Checkout), `nodeExecutable`, `stateDir`, `portStart`/`portEnd`, `leaseMinutes`. Keine persönlichen Pfade im veröffentlichten Bundle. Die Runtime wird aus dem gebauten CLI-Start erkannt; bei gepackten Hosts ggf. `runtimeDir` setzen. npm/pnpm verwenden die zum Controller gehörenden Launcher.

Beim DSH-Standardstart werden `scripts.build`/`scripts.watch` ausgewählter Bundles ausgeführt. Bei npm/pnpm übernimmt das Root-Skript seinen Build/Watch selbst, zusätzliche Bundles werden vorbereitet. Ein Quellordner hat höchstens einen Bundle-Watcher. Host-Plugin-Code wird durch Watch-Builds nicht automatisch neu geladen; neuer Gateway-Start lädt ihn neu. Client-HMR benötigt den passenden Runtime-Watcher; es wird nicht pauschal zugesichert.

Logs werden laufend gesammelt und auf 64.000 Zeichen begrenzt; Seiten enthalten maximal 16.384 Zeichen. Unvollständige Zeilen erscheinen nach Zeilenabschluss/Prozessende; übergroße unvollständige Zeilen werden sicher verworfen. Bekannte URL-Credentials werden maskiert, nicht beliebige Geheimnisse eines Fremdprogramms. Keine Zugangsdaten in Startargumenten oder Logausgaben ablegen.

Beim Stop/Lease-Ablauf werden alle erfassten Prozessgruppen beendet und abgewartet. Erst danach wird der Port frei. Unbestätigte Beendigung oder Controller-Neustart führt konservativ zu `unknown`, ohne automatische PID-Adoption. Bei regulärem Stop werden Gateway-Logs ohne `retainData` entfernt; Fehlerlogs bleiben zur Diagnose erhalten. Profile und Inventareinträge bleiben beim Stop erhalten, außer wenn die gebundene Steuer-Session archiviert ist: Dann folgt nach bestätigtem Stop automatisch `prune`. `retainData` sperrt dieses und manuelles Prune. DSH-Session-Jobs haben eine eigene Log-Aufbewahrung. Production bleibt unangetastet.

## Prüfungen

- `pnpm run check`: strikte Typprüfung für Runtime, Tests und Hilfsskripte, Build inklusive Identity-Unterbundle sowie JSON-/Tool-Verträge, Konfiguration, Ownership, Isolation, Logs, Archiv-Ereignisse, Neustart, Stop und Prune.
- `pnpm run smoke:archive`: reale isolierte Projekt-App schreibt eine Testdatenbank in `DEV_GATEWAY_DATA_DIR`; ein DSH-Testgateway legt ein eigenes Profil an. Archivbereinigung beendet beide Prozesse, entfernt deren Daten/Profile und lässt die Quellen stehen (ohne Core-Archiv-RPC).
- `pnpm run smoke`: echte isolierte DSH-Instanzen, npm/pnpm-DSH-Launcher sowie Nicht-DSH-Prozesse mit HTTP-, TCP- und Prozess-Readiness inklusive Browser-Login (nur HTTP/DSH), Logs und Prozesscleanup. `DSH_DEV_GATEWAY_RUNTIME_DIR` wählt eine separate gebaute Test-Runtime.
- `node verify-control.ts`: vorhandener lokaler Controller und Git-/Task-Master-Routen.

`start-control.ps1` und `open-control.ps1` sind lokale Betriebshelfer; ihre Rechnerpfade vor Verwendung prüfen. Eine Installation im Production-Profil ist ein separater, ausdrücklich freizugebender Schritt.
