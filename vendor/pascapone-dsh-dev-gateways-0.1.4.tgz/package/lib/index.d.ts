import type { Context } from '@deepseek-ai/cordis';
import type { ToolRunContext } from '@deepseek-ai/dsh-tools';
import type { GatewayManagerConfig } from './types.js';
export type * from './types.js';
type FetchRoute = Parameters<Context['connection']['fetch']['register']>[0];
export type GatewayOpenRoute = Omit<FetchRoute, 'fetch'> & {
    fetch(request: Request): Response;
};
export declare const inject: string[];
export declare function assertAgentStartPolicy(ctx: Pick<Context, 'sandboxPolicy'>, exec: Pick<ToolRunContext, 'agent'>): void;
export declare function apply(ctx: Context, config?: GatewayManagerConfig): Promise<void>;
