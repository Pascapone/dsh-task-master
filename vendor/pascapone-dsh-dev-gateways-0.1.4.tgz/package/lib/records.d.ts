import type { GatewayConfiguration, GatewayPublic } from './types.js';
export type PackageManifest = {
    name?: string;
    version?: string;
    packageManager?: string;
    scripts?: Record<string, unknown>;
    dsh?: {
        bundle?: {
            patch?: unknown;
        };
    };
};
export type StoredConfiguration = Partial<GatewayConfiguration> & {
    workspace?: string;
    packageName?: string;
};
export type StoredGateway = Omit<GatewayPublic, 'kind' | 'watching' | 'serverUrl'> & {
    kind?: GatewayPublic['kind'];
    home: string;
    initialLeaseMinutes?: number;
    watchEnabled?: boolean;
};
export declare function packageManifest(value: unknown): PackageManifest;
export declare function storedConfiguration(value: unknown): StoredConfiguration;
export declare function storedGateway(value: unknown): StoredGateway;
