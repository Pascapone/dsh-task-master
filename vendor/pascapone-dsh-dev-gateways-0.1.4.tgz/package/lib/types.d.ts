import type { DevGatewayManager } from './manager.js';
export type GatewayKind = 'dsh' | 'project';
export type GatewayStatus = 'starting' | 'ready' | 'stopping' | 'stopped' | 'failed' | 'unknown';
export type GatewayRunner = 'dsh' | 'npm' | 'pnpm' | 'command';
export type GatewayReadiness = 'http' | 'tcp' | 'process';
export type GatewayCaller = {
    operator?: boolean;
    owner?: string;
};
export type GatewayManagerConfig = {
    runtimeDir?: string;
    nodeExecutable?: string;
    stateDir?: string;
    portStart?: number;
    portEnd?: number;
    leaseMinutes?: number;
};
export type GatewayConfigureInput = {
    workspace?: string;
    kind?: GatewayKind;
    manager?: GatewayRunner;
    script?: string;
    command?: string[];
    args?: string[];
    readyMode?: GatewayReadiness;
    readyPath?: string;
};
export type GatewayStartInput = {
    workspace?: string;
    bundles?: string[];
    label?: string;
    requestId?: string;
    ownerKind?: 'agent' | 'operator';
    ownerSessionId?: string;
    sourceSessionId?: string;
    leaseMinutes?: number;
    retainData?: boolean;
    watch?: boolean;
};
export type GatewayConfiguration = {
    configured: boolean;
    bundle: boolean;
    kind: GatewayKind;
    manager: GatewayRunner;
    script?: string;
    command: string[];
    args: string[];
    readyMode: GatewayReadiness;
    readyPath: string;
    scripts: string[];
    commandPreview: string;
    dataPolicy: string;
};
/** Credential-free projection; absent lifecycle fields are omitted, never serialized as undefined. */
export type GatewayPublic = {
    id: string;
    requestId: string;
    ownerKind: 'agent' | 'operator';
    ownerSessionId?: string;
    sourceSessionId?: string;
    workspace: string;
    bundles: string[];
    label: string;
    kind: GatewayKind;
    port: number;
    serverUrl?: string;
    url?: string;
    jobId?: string;
    watching: boolean;
    status: GatewayStatus;
    createdAt: number;
    expiresAt: number;
    readyAt?: number;
    stoppedAt?: number;
    reason?: string;
    retainData: boolean;
    dataDir?: string;
    cleanupOnArchive?: boolean;
    cleanupPending?: boolean;
    cleanupError?: string;
    runtimeVersion?: string;
    pnpmVersion?: string;
    startCommand?: string;
};
/** The provider owns this contract; consumers never copy a parallel service definition. */
export type DevGateways = Pick<DevGatewayManager, 'ready' | 'configuration' | 'configure' | 'start' | 'list' | 'status' | 'access' | 'logs' | 'extend' | 'stop' | 'prune' | 'references' | 'browserUrl'>;
declare module '@deepseek-ai/cordis' {
    interface Context {
        devGateways: DevGateways;
    }
}
declare module '@deepseek-ai/dsh-jobs/view' {
    interface JobKindMap {
        'dev-gateway': 'dev-gateway';
    }
}
declare module '@deepseek-ai/dsh-workspace/types' {
    interface SessionActivityKindMap {
        'dev-gateway': true;
    }
}
